March 3, 2005    Dowell Griffin

2 IMPORTANT notes:

1) DO NOT run the .exe to do the install.   run setup.bat

2) If you have a problem with the installer exiting instantly without actually 
running the installation and you are running it from a UNC network drive mount
the network drive and browse to it (in other words, do not use a UNC)



INFORMATION:

This SiLabs USB driver uses same com port for all devices attached.

The older driver added a new com port for each new USB device attached.

This driver installation was built from a merge of the older version of SiLabs drivers that had been built with the installer customization utility and the newer drivers that were sent by SiLabs to allow multiple devices to use the same com port.  I could not get the new SiLabs driver installation to work following their instructions.  I merged the older .inf files into the newer ones and it worked.


I tested the new installation and it does work as desired: I connected two different devices and they both were accessible via the same port (com 4).


INSTALLATION RECOMMENDATION:

1) uninstall previous driver using control panel - add/remove programs
2) remove these two registry keys if they exist:

   HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\slabbus 

   HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\slabser 

3) run the new installation by launching Manufacturing_Preinstaller.bat